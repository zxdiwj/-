<?php
/**
 * Created by PhpStorm.
 * User: he
 * Date: 2018/8/25
 * Time: 19:46
 */

echo json_encode(['status' => true, 'msg' => '当前为专业版!']);